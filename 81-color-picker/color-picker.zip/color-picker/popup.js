const clrprw = document.getElementById('clr-preview');
const clrcd = document.getElementById('clr-code');
const clr = document.getElementById('clr');

clr.addEventListener('input', () => {
	clrprw.style.background = clr.value;
	console.log(clr.value);
	clrcd.value = clr.value;
});
